/*
    A daemon task that keeps an eye on memory usage of this app. If memory usage exceeds a pre-defined threshold, indicating a possible memory leak, the task will exit the app, to prevent a system freeze.
*/

import Cocoa

class MemoryMonitor: NSObject {
    
    fileprivate static var daemonThread: Thread?
    fileprivate static var taskExecutor: ScheduledTaskExecutor?
    
    fileprivate static let MAX_MEMORY_USAGE: Size = Size(size: 500, sizeUnit: SizeUnit.mb)
    fileprivate static let MONITOR_FREQUENCY_MILLIS: Int = 5000   // Poll interval
    
    // Start the memory monitor
    static func start() {
        
        taskExecutor = ScheduledTaskExecutor(intervalMillis: UInt32(MONITOR_FREQUENCY_MILLIS), task: {checkMemory()}, queue: DispatchQueue(queueName: "Aural.queues.monitoring"))
        taskExecutor?.startOrResume()
    }
    
    // Checks memory usage. If it exceeds the limit, the app is exited.
    static func checkMemory() {
        
        let memUsed = getMemoryUsage()
        
        if (memUsed != nil) {
            
            if (memUsed!.greaterThan(MAX_MEMORY_USAGE)) {
                NSLog("\n**** Max memory used (%@), exiting ... ****\n", (memUsed?.toString())!)
                exit(1)
            }
            
        } else {
            NSLog("Unable to obtain memory usage !\n")
        }
    }
        
    
    fileprivate static func getMemoryUsage() -> Size? {
        var info = task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout.size(ofValue: info) / MemoryLayout<integer_t>.size)
        let kerr = withUnsafeMutablePointer(to: &info) { infoPtr in
            return infoPtr.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { (machPtr: UnsafeMutablePointer<integer_t>) in
                return task_info(
                    mach_task_self_,
                    task_flavor_t(TASK_BASIC_INFO),
                    machPtr,
                    &count
                )
            }
        }
        guard kerr == KERN_SUCCESS else {
            return nil
        }  
        return Size(sizeBytes: info.resident_size)
    }
}
